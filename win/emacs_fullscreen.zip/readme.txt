https://bitbucket.org/alexander_manenko/emacs-fullscreen-win32/wiki/Home

(defun toggle-full-screen () (interactive) (shell-command "emacs_fullscreen.exe"))
(global-set-key [f11] 'toggle-full-screen)